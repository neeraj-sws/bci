<footer class="page-footer">
    <p class="mb-0">Copyright © {{ \Carbon\Carbon::now()->format('Y') }}. All rights reserved.</p>
</footer>
